// static/chat.js
document.addEventListener("DOMContentLoaded", () => {
  const input   = document.getElementById("input");
  const sendBtn = document.getElementById("send");
  const msgs    = document.getElementById("messages");

  function addMsg(text, cls){
    const el = document.createElement("div");
    el.className = cls;
    el.textContent = text;
    msgs.appendChild(el);
    msgs.scrollTop = msgs.scrollHeight;
  }

  async function enviar(msg){
    addMsg("Tú: " + msg, "me");
    try{
      const resp = await fetch("/chat", {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({mensaje: msg})
      });
      const data = await resp.json();
      const txt = data.response || "Sin respuesta";
      addMsg("Mascota: " + txt, "bot");
    }catch(e){
      addMsg("Mascota: error de conexión", "bot");
    }
  }

  sendBtn.addEventListener("click", () => {
    const txt = input.value.trim();
    if(!txt) return;
    input.value = "";
    enviar(txt);
  });

  input.addEventListener("keypress", (e) => {
    if(e.key === "Enter") sendBtn.click();
  });
});
