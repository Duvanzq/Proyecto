// static/pet.js
document.addEventListener("DOMContentLoaded", () => {
  const petImg   = document.getElementById("pet-img");
  const hungerBar = document.querySelector("#hunger .fill");
  const healthBar = document.querySelector("#health .fill");
  const streakEl  = document.getElementById("streak");
  const questionBox = document.getElementById("question-box");
  const qSpan       = document.getElementById("daily-question");
  const answerInput = document.getElementById("answer-input");
  const answerBtn   = document.getElementById("answer-btn");

  // -------------------------------------------------
  //  Funciones para consultar el API
  // -------------------------------------------------
  async function fetchState(){
    const r = await fetch("/state");
    const s = await r.json();
    updateBars(s);
    updateSprite(s);
    updateStreak(s);
  }

  async function fetchQuestion(){
    const r = await fetch("/daily_question");
    const q = await r.json();
    if(q.question && !q.answered){
      qSpan.textContent = q.question;
      questionBox.style.display = "block";
    }else{
      questionBox.style.display = "none";
    }
  }

  // -------------------------------------------------
  //  UI actualizaciones
  // -------------------------------------------------
  function updateBars(state){
    const hungerPct = Math.max(0, Math.min(100, (state.hunger/20)*100));
    const healthPct = Math.max(0, Math.min(100, (state.health/20)*100));
    hungerBar.style.width = hungerPct + "%";
    healthBar.style.width = healthPct + "%";
  }

  function updateSprite(state){
    let sprite = "wolf_idle.png";
    if(state.mood === "feliz" && state.hunger > 10) sprite = "wolf_happy.png";
    else if(state.mood === "enfermo" || state.health <= 5) sprite = "wolf_sick.png";
    if(!petImg.src.endsWith(sprite)){
      petImg.src = "/static/images/" + sprite;
    }
  }

  function updateStreak(state){
    streakEl.textContent = `Streak: ${state.streak} día(s)`;
  }

  // -------------------------------------------------
  //  Responder a la pregunta diaria
  // -------------------------------------------------
  answerBtn.addEventListener("click", async () => {
    const ans = answerInput.value.trim();
    if(!ans) return;
    answerBtn.disabled = true;
    try{
      const r = await fetch("/daily_question/answer", {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({answer: ans})
      });
      const res = await r.json();
      // Mostrar mensaje en el chat
      const msgs = document.getElementById("messages");
      const el = document.createElement("div");
      el.className = "bot";
      el.textContent = `Mascota: ${res.msg}`;
      msgs.appendChild(el);
      msgs.scrollTop = msgs.scrollHeight;

      // Actualizamos UI (hunger, health, streak) después de contestar
      await fetchState();
    }finally{
      answerBtn.disabled = false;
      questionBox.style.display = "none";
      answerInput.value = "";
    }
  });

  // -------------------------------------------------
  //  Bucle de actualización cada X segundos
  // -------------------------------------------------
  setInterval(fetchState, 5000);    // cada 5 s
  setInterval(fetchQuestion, 10000); // cada 10 s (para la medianoche)

  // Carga inmediata al iniciar
  fetchState();
  fetchQuestion();
});
