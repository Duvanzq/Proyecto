# --------------------------------------------------------------
#  Minetico – Mascota virtual Minecraft (llama3:latest)
# --------------------------------------------------------------
import os
import json
import random
import requests
from datetime import datetime, timedelta

from flask import Flask, render_template, request, jsonify
from apscheduler.schedulers.background import BackgroundScheduler
from dotenv import load_dotenv                         # <-- carga .env

# -------------------------- CARGA DE .ENV ----------------------
load_dotenv()                                          # <‑‑ IMPORTANTE

# -------------------------- CONSTANTES ----------------------
BASE_DIR   = os.path.abspath(os.path.dirname(__file__))
KB_PATH    = os.path.join(BASE_DIR, "kb.json")
STATE_PATH = os.path.join(BASE_DIR, "pet_state.json")
QUEST_PATH = os.path.join(BASE_DIR, "questions.json")   # (opcional, no usado ahora)

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static"),
)

# Variables leídas del .env (con valores por defecto)
LLAMA_URL      = os.getenv("LLAMA_URL", "http://127.0.0.1:11434/api/generate")
OLLAMA_MODEL   = os.getenv("OLLAMA_MODEL", "llama3:latest")
LLAMA_TIMEOUT  = int(os.getenv("LLAMA_TIMEOUT", "30"))

SYSTEM_PROMPT = (
    "Eres 'Minetico', una mascota virtual experta en Minecraft. "
    "Responde breve, amable y útil. Incluye pasos concretos, comandos o niveles cuando apliquen. "
    "Mantén personalidad carismática."
)

# --------------------------------------------------------------
#  CARGA / GUARDADO DE LA BASE DE CONOCIMIENTO (KB)
# --------------------------------------------------------------
def load_kb() -> dict:
    if not os.path.exists(KB_PATH):
        default = {
            "diamante": "Los diamantes se encuentran entre Y= -59 y -16; mejor entre -58 y -59.",
            "redstone": "Redstone abunda entre Y= -64 y -32; útil para circuitos y granjas."
        }
        with open(KB_PATH, "w", encoding="utf-8") as f:
            json.dump(default, f, ensure_ascii=False, indent=2)
        return default
    with open(KB_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_kb(kb: dict):
    with open(KB_PATH, "w", encoding="utf-8") as f:
        json.dump(kb, f, ensure_ascii=False, indent=2)


KB = load_kb()


def lookup_kb(prompt: str) -> str:
    """Devuelve fragmentos de la KB que coinciden con el texto del usuario."""
    p = (prompt or "").lower()
    snippets = []
    for term, txt in KB.items():
        if term.lower() in p or any(word in p for word in term.lower().split()):
            snippets.append(f"{term.capitalize()}: {txt}")
    return "\n".join(snippets)


# --------------------------------------------------------------
#  ESTADO DE LA MASCOTA (pet_state.json)
# --------------------------------------------------------------
def load_state() -> dict:
    defaults = {
        "name": "Minetico",
        "mood": "feliz",
        "hunger": 20,          # 0‑20
        "health": 20,          # 0‑20
        "streak": 0,
        "last_visit": None,
        "last_update": None,
        "daily_question": {
            "date": None,
            "question": "",
            "answer": "",
            "answered": False,
            "damage": 3
        }
    }
    if not os.path.exists(STATE_PATH):
        with open(STATE_PATH, "w", encoding="utf-8") as f:
            json.dump(defaults, f, ensure_ascii=False, indent=2)
        return defaults
    with open(STATE_PATH, "r", encoding="utf-8") as f:
        state = json.load(f)

    # Si el JSON viejo no tiene algunos campos, los añadimos:
    for k, v in defaults.items():
        state.setdefault(k, v)
    return state


def save_state(state: dict):
    with open(STATE_PATH, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


PET_STATE = load_state()


# --------------------------------------------------------------
#  HAMBRE / VIDA (decay automático)
# --------------------------------------------------------------
def iso_to_dt(s: str) -> datetime:
    """Convierte una cadena ISO a datetime (maneja fechas ó datetimes)."""
    try:
        return datetime.fromisoformat(s)
    except Exception:
        return datetime(1970, 1, 1)


def now_iso() -> str:
    return datetime.utcnow().isoformat()


def update_hunger_and_health(state: dict) -> dict:
    """Cada 30 min ↓ hambre, y si hambre==0, cada hora ↓ vida."""
    last = state.get("last_update")
    if not last:
        state["last_update"] = now_iso()
        return state

    now = datetime.utcnow()
    elapsed = now - iso_to_dt(last)

    # Hambre disminuye 1 punto cada 30 min
    hunger_steps = elapsed // timedelta(minutes=30)
    if hunger_steps:
        state["hunger"] = max(0, state["hunger"] - hunger_steps)
        state["last_update"] = now_iso()

    # Si hambre está 0, la vida pierde 1 punto cada hora
    if state["hunger"] == 0:
        health_steps = elapsed // timedelta(hours=1)
        if health_steps:
            state["health"] = max(0, state["health"] - health_steps)

    # Mood (estado de ánimo) según health
    if state["health"] >= 15:
        state["mood"] = "feliz"
    elif state["health"] >= 8:
        state["mood"] = "cansado"
    else:
        state["mood"] = "enfermo"

    return state


def update_streak(state: dict) -> dict:
    """Incrementa la racha (streak) si el usuario vuelve al día siguiente."""
    today = datetime.utcnow().date()
    last_visit_str = state.get("last_visit")
    if not last_visit_str:
        state["streak"] = 1
    else:
        last_date = iso_to_dt(last_visit_str).date()
        diff = (today - last_date).days
        if diff == 1:
            state["streak"] += 1
        elif diff > 1:
            state["streak"] = 1    # se rompió la cadena
    state["last_visit"] = today.isoformat()
    return state


# --------------------------------------------------------------
#  PREGUNTA DIARIA (zombie)
# --------------------------------------------------------------
def generate_daily_question(state: dict) -> dict:
    """Crea o reutiliza la pregunta del día."""
    today = datetime.utcnow().date().isoformat()
    dq = state.get("daily_question", {})
    if dq.get("date") == today and dq.get("question"):
        return state                         # ya la tenemos

    # Intentamos usar la KB para crear una pregunta sencilla
    if KB:
        term, txt = random.choice(list(KB.items()))
        question = f"Según la KB, ¿dónde se encuentra {term}?"
        answer   = txt.split(";")[0].lower().strip()
    else:
        # fallback genérico
        question = "¿Cuál es el bloque más valioso del Nether?"
        answer   = "ancient debris"

    state["daily_question"] = {
        "date": today,
        "question": question,
        "answer": answer,
        "answered": False,
        "damage": 3
    }
    return state


def daily_question_job():
    """Job que corre a medianoche (cron) y crea la pregunta del día."""
    global PET_STATE
    PET_STATE = generate_daily_question(PET_STATE)
    save_state(PET_STATE)


# --------------------------------------------------------------
#  PROGRAMAR TAREA (APScheduler)
# --------------------------------------------------------------
scheduler = BackgroundScheduler()
scheduler.add_job(
    func=daily_question_job,
    trigger="cron",
    hour=0,
    minute=5,               # 00:05 UTC es suficientemente pronto
    id="daily_question_job",
    replace_existing=True,
)
scheduler.start()


# --------------------------------------------------------------
#  RESPUESTA FALLBACK (si LLaMA falla)
# --------------------------------------------------------------
def generate_response(prompt: str) -> str:
    low = (prompt or "").lower()
    if any(g in low for g in ["hola", "buenas", "hey"]):
        return f"¡Hola! Soy {PET_STATE.get('name','tu mascota')} 🐾 — ¿minar, construir o domesticar mobs?"
    frases = [
        "¡Buena idea! ¿Quieres que te sugiera un plano de base?",
        "¡Genial! ¿Te cuento un truco para conseguir más hierro?",
        "¡Aventura! ¿Exploramos una cueva?"
    ]
    return random.choice(frases)


def parse_llama_response(j):
    """Extrae el texto del JSON devuelto por Ollama (varios formatos)."""
    if not j:
        return None
    if isinstance(j, dict):
        for key in ("response", "text", "output"):
            if key in j and isinstance(j[key], str):
                return j[key]
        # formato "choices" o "results"
        choices = j.get("choices") or j.get("results") or []
        if isinstance(choices, list) and choices:
            first = choices[0]
            for k in ("content", "text", "output"):
                if k in first and isinstance(first[k], str):
                    return first[k]
            # "content" puede ser lista de dicts
            if isinstance(first.get("content"), list):
                for it in first["content"]:
                    if isinstance(it, dict) and it.get("type") == "output_text":
                        return it.get("text")
    return str(j)


# --------------------------------------------------------------
#  RUTAS FLASK
# --------------------------------------------------------------
@app.route("/")
def home():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    mensaje = data.get("mensaje", "").strip()
    if not mensaje:
        return jsonify({"response": "Escribe algo sobre Minecraft."})

    # Actualizamos el estado antes de generar la respuesta
    global PET_STATE
    PET_STATE = update_hunger_and_health(PET_STATE)
    PET_STATE = update_streak(PET_STATE)
    save_state(PET_STATE)

    # 1️⃣ Buscamos coincidencias en la KB
    kb_snips = lookup_kb(mensaje)

    # 2️⃣ Construimos el prompt que enviamos a Ollama
    prompt_to_send = SYSTEM_PROMPT
    prompt_to_send += f"\nMascota: nombre={PET_STATE.get('name')}, estado={PET_STATE.get('mood')}, hambre={PET_STATE.get('hunger')}, vida={PET_STATE.get('health')}\n"
    if kb_snips:
        prompt_to_send += "\nConocimientos relevantes:\n" + kb_snips
    prompt_to_send += f"\nUsuario: {mensaje}\nRespuesta:"

    # 3️⃣ Llamada a Ollama
    try:
        payload = {
            "model": OLLAMA_MODEL,
            "prompt": prompt_to_send,
            "stream": False
        }
        resp = requests.post(LLAMA_URL, json=payload, timeout=LLAMA_TIMEOUT)
        if resp.status_code == 200:
            j = resp.json()
            txt = parse_llama_response(j) or generate_response(mensaje)
            return jsonify({"response": txt})
    except Exception:
        # Si la petición falla por cualquier razón usamos el fallback
        pass

    # 4️⃣ fallback
    return jsonify({"response": generate_response(mensaje)})


@app.route("/kb", methods=["GET", "POST"])
def kb_route():
    global KB
    if request.method == "GET":
        return jsonify(KB)

    data = request.get_json(silent=True) or {}
    term = (data.get("term") or "").strip()
    text = (data.get("text") or "").strip()
    if not term or not text:
        return jsonify({"error": "term y text requeridos"}), 400

    KB[term] = text
    save_kb(KB)
    return jsonify({"ok": True, "kb": KB})


@app.route("/upload_kb", methods=["POST"])
def upload_kb():
    global KB
    f = request.files.get("file")
    if not f:
        return jsonify({"error": "file requerido"}), 400
    try:
        data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError("JSON debe ser un objeto {term: text}")
        KB = data
        save_kb(KB)
        return jsonify({"ok": True, "kb": KB})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/state", methods=["GET", "POST"])
def state_route():
    global PET_STATE
    if request.method == "GET":
        # antes de devolver, actualizamos hambre/vida y streak
        PET_STATE = update_hunger_and_health(PET_STATE)
        PET_STATE = update_streak(PET_STATE)
        save_state(PET_STATE)
        return jsonify(PET_STATE)

    data = request.get_json(silent=True) or {}
    PET_STATE.update(data)
    save_state(PET_STATE)
    return jsonify(PET_STATE)


@app.route("/daily_question", methods=["GET"])
def daily_question_get():
    """Devuelve la pregunta del día (crea una si no existe)."""
    global PET_STATE
    PET_STATE = generate_daily_question(PET_STATE)
    save_state(PET_STATE)
    return jsonify(PET_STATE["daily_question"])


@app.route("/daily_question/answer", methods=["POST"])
def daily_question_answer():
    """Recibe la respuesta del usuario y actualiza hambre/vida."""
    global PET_STATE
    data = request.get_json(silent=True) or {}
    answer = (data.get("answer") or "").lower().strip()
    dq = PET_STATE.get("daily_question", {})

    if not dq or not dq.get("question"):
        return jsonify({"error": "No hay pregunta para hoy"}), 400

    if dq.get("answered"):
        return jsonify({"msg": "Ya contestaste hoy", "state": PET_STATE})

    # Comparación simple (contiene la palabra clave)
    correct = answer and (dq["answer"] in answer or answer in dq["answer"])

    if correct:
        PET_STATE["hunger"] = min(20, PET_STATE["hunger"] + 2)
        PET_STATE["health"] = min(20, PET_STATE["health"] + 1)
        msg = "¡Respuesta correcta! 🎉"
    else:
        PET_STATE["health"] = max(0, PET_STATE["health"] - dq.get("damage", 3))
        msg = f"Incorrecto. Perdiste {dq.get('damage',3)} de salud."

    dq["answered"] = True
    PET_STATE["daily_question"] = dq
    save_state(PET_STATE)

    return jsonify({"correct": correct, "msg": msg, "state": PET_STATE})


@app.route("/__debug")
def _debug():
    """Información de depuración (útil para ver rutas y KB)."""
    info = {
        "cwd": BASE_DIR,
        "template_folder": app.template_folder,
        "static_folder": app.static_folder
    }
    try:
        info["templates"] = os.listdir(app.template_folder) if os.path.isdir(app.template_folder) else []
        info["statics"] = os.listdir(app.static_folder) if os.path.isdir(app.static_folder) else []
        info["kb_keys"] = list(KB.keys())
    except Exception as e:
        info["error"] = str(e)
    return jsonify(info)


if __name__ == "__main__":
    # Muestra el mensaje una sola vez
    print("🚀 Iniciando Minetico → http://0.0.0.0:5000")
    # host='0.0.0.0' → escucha en IPv4 y IPv6
    # use_reloader=False → evita que el proceso “se reinicie” y desaparezca
    app.run(host="0.0.0.0", port=5000, debug=True, use_reloader=False)

